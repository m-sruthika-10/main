package one.microproject.proxyserver.impl;

public interface CloseListener {

    void onClose();

}
