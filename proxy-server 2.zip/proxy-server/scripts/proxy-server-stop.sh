#!/bin/bash

killall java
